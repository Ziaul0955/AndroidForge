# Facebook Post to PDF Android project
Includes Facebook Share-menu receiver for shared text links and image files, photo-to-PDF creation, and merging two or more existing PDF files in selected order. PDF merge uses PDFBox-Android and Gradle downloads the dependency at build time.

Important: Facebook often shares only a URL, not every image in the post. Android apps cannot extract private/login-restricted album images from a URL without authorized access. When only a link is shared, save/select the photos manually.

Build with Android Studio: open this folder, sync Gradle, Build > Build Bundle(s) / APK(s) > Build APK(s). This is source code, not a precompiled APK.
